package ctrl;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.http.*;
import org.json.simple.*;
import org.json.simple.parser.*;
import org.springframework.stereotype.*;
import org.springframework.ui.*;
import org.springframework.web.bind.annotation.*;
import svc.*;
import vo.*;

@Controller
public class JsonCtrl {
	private JsonSvc jsonSvc;
	
	public void setJsonSvc(JsonSvc jsonSvc) {
		this.jsonSvc = jsonSvc;
	}

	@GetMapping("/jsonIndex")
	public String jsonIndex() {
		return "json/jsonIndex";
	}
	
	@GetMapping("/jsObject")
	public String jsObject() {
		return "json/jsObject";
	}
	
	@GetMapping("/test01Stringify")
	public String test01Stringify() {
		return "json/test01Stringify";
	}
	
	@GetMapping("/test02Parse")
	public String test02Parse() {
		return "json/test02Parse";
	}
	
	@GetMapping("/whyJson")
	public String whyJson() {
		return "json/whyJson";
	}
	
	@RequestMapping(value="/noJson", method=RequestMethod.GET, produces="application/text; charset=utf8")
	@ResponseBody	// 자바의 객체를 http 응답용 객체로 변환하여 클라이언트에 전송
	public String noJson() {
		String[] arr = {"홍길동", "전우치", "임꺽정"};
		String result = "";
		for (int i = 0 ; i < arr.length ; i++) {
			result += "," + arr[i];
		}
		
		return result.substring(1);
	}
	
	@RequestMapping(value="/useJson", method=RequestMethod.GET, produces="application/text; charset=utf8")
	@ResponseBody
	public String useJson() {
		String[] arr = {"홍길동", "전우치", "임꺽정"};
		org.json.JSONArray result = new org.json.JSONArray(arr);
		// JSONArray는 List에 가까움(특히, ArrayList)
		
		return result.toString();
	}
	
	@GetMapping("/jsonFile")
	public String jsonFile() {
		return "json/jsonFile";
	}
	
	@GetMapping("/jsonArray1")
	public String jsonArray1() {
		return "json/jsonArray1";
	}
	
	@PostMapping("/jsonArray2")
	public String jsonArray2(HttpServletRequest request) throws Exception {
		request.setCharacterEncoding("UTF-8");
		String jsonStr = request.getParameter("jsonArr");
		// 특정 문자열 등을 JSON객체로 변환할 때 사용하는 인스턴스
		JSONParser p = new JSONParser();
		JSONArray jsonArr = new JSONArray();
		jsonArr = (JSONArray)p.parse(jsonStr);
		// json형식의 문자열(jsonStr)을 JSONArray로 변환하여 저장
		// JSONArray는 배열보다 List에 가까움(특히, ArrayList)
		for (int i = 0 ; i < jsonArr.size() ; i++) {
			JSONObject jo = (JSONObject)jsonArr.get(i);
			// jsonArr에 들어있는 요소를 JSONObject형 인스턴스로 변환(안에있는 값을 하나씩 쓰려고)
			// jsonArray는 리스트(List)이므로 인덱스번호를 이용하여 데이터를 추출함
			System.out.println("id : " + jo.get("id") + " / addr : " + jo.get("addr"));
			// JSONObject는 맵(MAP)이므로 키를 이용하여 데이터를 추출함
		}
		
		request.setAttribute("jsonStr", jsonStr.replaceAll("\"", "\'"));
		// json형식의 문자열을 request에 저장
		
		return "json/jsonArray2";
	}
	
	@GetMapping("/jsonArrayDb1")
	public String jsonArrayDb1(Model model, HttpServletRequest request) throws Exception {
		request.setCharacterEncoding("UTF-8");
		String schtype = request.getParameter("schtype");
		String keyword = request.getParameter("keyword");
		String where = "";
		
		if (schtype == null || keyword == null) {
			schtype = "";
			keyword = "";
		} else if (!schtype.equals("") && !keyword.equals("")) {
			URLEncoder.encode(keyword);
			keyword = keyword.trim();
			where = " AND mi_" + schtype + " LIKE '%" + keyword + "%' ";
		}
		
		List<MemberInfo> memberList = jsonSvc.getMemberList(where);
		PageInfo pi = new PageInfo();
		pi.setSchtype(schtype);
		pi.setKeyword(keyword);
		
		request.setAttribute("pi", pi);
		request.setAttribute("memberList", memberList);		
		
		return "json/jsonArrayDb1";
	}
	
	@PostMapping("/jsonArrayDb2")
	public String jsonArrayDb2(HttpServletRequest request) throws Exception {
		request.setCharacterEncoding("UTF-8");
		String jsonStr = request.getParameter("jsonStr");
		
		JSONParser p = new JSONParser();
		JSONArray jsonArr = new JSONArray();
		jsonArr = (JSONArray)p.parse(jsonStr);	// JSON형식의 문자열을 JSONArray로 변환하여 저장
		for (int i = 0 ; i < jsonArr.size() ; i++) {
			JSONObject jo = (JSONObject)jsonArr.get(i);	// jsonArr 배열에 있는 데이터를 MAP과 비슷한 key와 value가 있는 JSONObject
			System.out.println("id : " + jo.get("id") + " / name : " + jo.get("name"));
		}
		
		request.setAttribute("jsonStr", jsonStr.replaceAll("\"", "\'"));
		
		return "json/jsonArrayDb2";
	}
	
	@GetMapping("/jsonArray3")
	public String jsonArray3() {
		return "json/jsonArray3";
	}
	
	@GetMapping("/addrOpenApi")
	public String addrOpenApi() {
		return "json/addrOpenApi";
	}
	
	@GetMapping("/openApi1")
	public String openApi1(HttpServletRequest request) throws Exception {
		request.setCharacterEncoding("UTF-8");
		StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1262000/CountryPopulationService2/getCountryPopulationList2"); /*URL*/
		
		// Open API의 요청 규격에 맞는 쿼리스트링 생성
		urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=dP5pdLUplQOdajNR65YvdF5dWIBCi%2FxQCwdQ5UsRKIphuPKTnr7asipTYSx%2Ffk6XgcME3UaH5jfyZTNRhxLwKg%3D%3D"); /*Service Key*/
		urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("39", "UTF-8")); /*페이지 번호*/
		urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("10", "UTF-8")); /*한 페이지 결과 수*/
//		urlBuilder.append("&" + URLEncoder.encode("cond[country_nm::EQ]","UTF-8") + "=" + URLEncoder.encode("가나", "UTF-8")); /*국가명*/
//		urlBuilder.append("&" + URLEncoder.encode("cond[country_iso_alp2::EQ]","UTF-8") + "=" + URLEncoder.encode("GH", "UTF-8")); /*ISO 2자리코드*/
		urlBuilder.append("&" + URLEncoder.encode("returnType","UTF-8") + "=" + URLEncoder.encode("JSON", "UTF-8")); /*XML 또는 JSON*/
		
		// URL 객체 생성
		URL url = new URL(urlBuilder.toString());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/json");
		System.out.println("Response code: " + conn.getResponseCode());
		
		BufferedReader rd;	// Open API에서 보낸 데이터를 받아 저장할 객체 선언
		if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else {
			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		
		StringBuilder sb = new StringBuilder();	// 받아온 데이터 전체를 문자열로 저장할 객체
		String line; // 받아온 데이터를 한 줄씩 문자열로 받아 저장할 객체
		while ((line = rd.readLine()) != null) {	// 읽어들인 한 줄의 문자열을 line에 저장(더이상 읽어들일 데이터가 없으면 null)
			sb.append(line);	// 읽어들인 한 줄의 문자열을 차례대로 누적 저장
		}	// open api에서 보낸 json 형식의 문자열을 sb에 저장
		rd.close();
		conn.disconnect();
		
		// 받아놓은 json 형식의 문자열을 JSONArray로 변환
		JSONParser p = new JSONParser();
		JSONObject jo = (JSONObject)p.parse(sb.toString());	// 스트링으로 변환 | p.parse(new String(sb)); 새로운 스트링으로 생성
		// sb에 저장된 값을 String으로 변환하여 JSONObject 객체로 생성
		// 받아온 값들 중 'data'라는 키에 해당하는 값만 사용하기 위해
		JSONArray dataList = (JSONArray)jo.get("data");
		// 'data'라는 키에 해당하는 값들을 JSONArray 객체로 저장
		
		request.setAttribute("dataList", dataList);
		
		return "json/openApi1";
	}
	
	@GetMapping("/openApi2")
	public String openApi2(HttpServletRequest request) throws Exception {
		request.setCharacterEncoding("UTF-8");
		StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1262000/CountryCovid19SafetyServiceNew/getCountrySafetyNewsListNew"); /*URL*/
		urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=dP5pdLUplQOdajNR65YvdF5dWIBCi%2FxQCwdQ5UsRKIphuPKTnr7asipTYSx%2Ffk6XgcME3UaH5jfyZTNRhxLwKg%3D%3D"); /*Service Key*/
		urlBuilder.append("&" + URLEncoder.encode("returnType","UTF-8") + "=" + URLEncoder.encode("JSON", "UTF-8")); /*XML 또는 JSON*/
		urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("10", "UTF-8")); /*한 페이지 결과 수*/
		urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지 번호*/
//		urlBuilder.append("&" + URLEncoder.encode("cond[country_nm::EQ]","UTF-8") + "=" + URLEncoder.encode("가나", "UTF-8")); /*한글 국가명*/
//		urlBuilder.append("&" + URLEncoder.encode("cond[country_iso_alp2::EQ]","UTF-8") + "=" + URLEncoder.encode("GH", "UTF-8")); /*ISO 2자리코드*/
		URL url = new URL(urlBuilder.toString());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/json");
		System.out.println("Response code: " + conn.getResponseCode());
		BufferedReader rd;
		if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
		    rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else {
		    rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = rd.readLine()) != null) {
		    sb.append(line);
		}
		rd.close();
		conn.disconnect();
//		System.out.println(sb.toString());
		JSONParser p = new JSONParser();
		JSONObject jo = (JSONObject)p.parse(sb.toString());
		JSONArray dataList = (JSONArray)jo.get("data");
		
		request.setAttribute("dataList", dataList);
				
		return "json/openApi2";
	}
}
