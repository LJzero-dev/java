package dao;

import java.sql.*;
import javax.sql.*;
import java.util.*;
import org.springframework.jdbc.core.*;
import org.springframework.jdbc.support.*;
import vo.*;

public class FreeDao {
	private JdbcTemplate jdbc;
	
	public FreeDao(DataSource dataSource) {
		this.jdbc = new JdbcTemplate(dataSource);
	}

	// 검색된(검색어가 있을 경우) 게시글의 총 개수를 리턴하는 메소드
	public int getFreeListCount(String where) {
		String sql = "SELECT COUNT(*) FROM t_free_list " + where;
		int rcnt = jdbc.queryForObject(sql, Integer.class);
		return rcnt;
	}

	// 게시글의 목록을 FreeList형 인스턴스를 저장한 List로 리턴하는 메소드
	public List<FreeList> getFreeList(String where, int cpage, int psize) {
		String sql = "SELECT fl_idx, fl_title, fl_reply, fl_writer, fl_read, " + 
				" IF(CURDATE() = DATE(fl_date), RIGHT(fl_date, 8), MID(fl_date, 3, 8)) AS wdate FROM t_free_list " + 
				where + " ORDER BY fl_idx DESC LIMIT " + ((cpage - 1) * psize) + ", " + psize;
		
		List<FreeList> freeList = jdbc.query(sql, (ResultSet rs, int rowNum) -> {
			FreeList fl = new FreeList();
			fl.setFl_idx(rs.getInt("fl_idx"));
			fl.setFl_writer(rs.getString("fl_writer"));
			fl.setFl_read(rs.getInt("fl_read"));
			fl.setFl_date(rs.getString("wdate").replace("-", "."));
			
			String title = "";
			int cnt = 30;
			if (rs.getInt("fl_reply") > 0) {
				title = " [" + rs.getInt("fl_reply") + "]";
				cnt -= 3;
			}
			
			if (rs.getString("fl_title").length() > cnt) {
				title = rs.getString("fl_title").substring(0, cnt - 3) + "..." + title;
			} else {
				title = rs.getString("fl_title") + title;
			}
			fl.setFl_title(title);
			
			return fl;
		});
		return freeList;
	}

	// 지정한 게시글의 조회수를 1증가 시키는 메소드
	public int readUpdate(int flidx) {
		String sql = "UPDATE t_free_list SET fl_read = fl_read + 1 WHERE fl_idx = " + flidx;
		int result = jdbc.update(sql);
		return result;
	}

	// 지정한 게시글의 내용을 FreeList형 인스턴스로 리턴하는 메소드
	public FreeList getFreeInfo(int flidx) {
		int result = readUpdate(flidx);
		
		String sql = "SELECT * FROM t_free_list WHERE fl_isview = 'y' AND fl_idx = " + flidx;
		FreeList fl = jdbc.queryForObject(sql, new RowMapper<FreeList>() {
					@Override
					public FreeList mapRow(ResultSet rs, int rowNum) throws SQLException {
						FreeList fl = new FreeList();
						fl.setFl_idx(rs.getInt("fl_idx"));
						fl.setFl_writer(rs.getString("fl_writer"));
						fl.setFl_title(rs.getString("fl_title"));
						fl.setFl_content(rs.getString("fl_content").replace("\r\n", "<br />"));
						fl.setFl_reply(rs.getInt("fl_reply"));
						fl.setFl_read(rs.getInt("fl_read"));
						fl.setFl_ip(rs.getString("fl_ip"));
						fl.setFl_date(rs.getString("fl_date"));
						
						return fl;
					}
				});

		return fl;
	}
}
