package dao;

import javax.sql.*;
import org.springframework.jdbc.core.*;
import vo.*;

public class MemberDao {
	private JdbcTemplate jdbc;
	
	public MemberDao(DataSource dataSource) {
		this.jdbc = new JdbcTemplate(dataSource);
	}

	public int memberInsert(MemberInfo mi) {
		String sql = "INSERT INTO t_member_info VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1000, 'a', NOW(), NULL)";
		int result = jdbc.update(sql, mi.getMi_id(), mi.getMi_pw(), mi.getMi_name(), mi.getMi_gender(), mi.getMi_birth(), 
				mi.getMi_phone(), mi.getMi_email(), mi.getMi_isad());
		
		sql = "INSERT INTO t_member_point (mi_id, mp_point, mp_desc) VALUES ('" + mi.getMi_id() + "', 'a', '가입 축하금')";
		result += jdbc.update(sql);
		
		return result;
	}

	public int chkDupId(String uid) {
		String sql = "SELECT COUNT(*) FROM t_member_info WHERE mi_id = '" + uid + "'";
		int result = jdbc.queryForObject(sql, Integer.class);
				
		return result;
	}

	public int memberUpdate(MemberInfo mi) {
		String sql = "UPDATE t_member_info SET mi_phone = '" + mi.getMi_phone() + "', mi_email = '" + mi.getMi_email() + "', " + 
				" mi_isad = '" + mi.getMi_isad() + "' WHERE mi_id = '" + mi.getMi_id() + "' ";
		int result = jdbc.update(sql);
		
		return result;
	}
}
