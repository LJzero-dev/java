package config;

import org.springframework.context.annotation.*;
import dao.*;
import svc.*;

@Configuration
public class JstlConfig {
// 일정 관리 관련 작업 설정 클래스
	
	@Bean
	public JstlDao jstlDao() {
		return new JstlDao(DbConfig.dataSource());
	}
	
	@Bean
	public JstlSvc jstlSvc() {
		JstlSvc jstlSvc = new JstlSvc();
		jstlSvc.setJstlDao(jstlDao());;
		return jstlSvc;
	}
}
