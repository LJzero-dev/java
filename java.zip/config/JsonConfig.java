package config;

import org.springframework.context.annotation.*;
import dao.*;
import svc.*;

@Configuration
public class JsonConfig {
	@Bean
	public JsonDao jsonDao() {
		return new JsonDao(DbConfig.dataSource());
	}
	
	@Bean
	public JsonSvc jsonSvc() {
		JsonSvc jsonSvc = new JsonSvc();
		jsonSvc.setJsonDao(jsonDao());;
		return jsonSvc;
	}
}
