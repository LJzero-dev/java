package config;

import org.springframework.context.annotation.*;
import org.springframework.jdbc.datasource.*;		// 트랜잭션 추가
import org.springframework.transaction.*;			// 트랜잭션 추가
import org.springframework.transaction.annotation.*;// 트랜잭션 추가
import dao.*;
import svc.*;

// 회원 관련 작업 설정 클래스
@Configuration
@EnableTransactionManagement
// @Transactional 애노테이션이 붙은 메소드를 트랜잭션 범위에서 실행하는 기능으로 활성화시킴
// 등록한 PlatFormTransactionManager 빈을 사용하여 트랜잭션을 적용함
public class MemberConfig {
		
	@Bean
	public PlatformTransactionManager transctionManager() {
		DataSourceTransactionManager tm = new DataSourceTransactionManager();
		tm.setDataSource(DbConfig.dataSource());
		return tm;
	}
	
	@Bean
	public LoginDaoSpr loginDaoSpr() {
		return new LoginDaoSpr(DbConfig.dataSource());
	}
	
	@Bean
	public LoginSvcSpr loginSvcSpr() {
		LoginSvcSpr loginSvcSpr = new LoginSvcSpr();
		loginSvcSpr.setLoginDaoSpr(loginDaoSpr());
		return loginSvcSpr;
	}
	
	@Bean
	public MemberDao memberDao() {
		return new MemberDao(DbConfig.dataSource());
	}
	
	@Bean
	public MemberSvc memberSvc() {
		MemberSvc memberSvc = new MemberSvc();
		memberSvc.setMemberDao(memberDao());;
		return memberSvc;
	}
}
