package config;


import org.springframework.context.annotation.*;
import dao.*;
import svc.*;

@Configuration
public class FreeConfig {

	@Bean
	public FreeDao freeDao() {
		return new FreeDao(DbConfig.dataSource());
	}

	@Bean
	public FreeSvc freeSvc() {
		FreeSvc freeSvc = new FreeSvc();
		freeSvc.setFreeDao(freeDao());
		return freeSvc;
	}
}
