package vo;

public class ReviewList {	// ���� �ı� ������ ������ Ŭ����
	private String mi_id, oi_id, pi_id, rl_name, rl_title, rl_content, re_img, rl_ip, rl_isview, rl_date;
	private int rl_idx, ps_idx, rl_read, rl_good; 
	private double rl_score;
	
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getOi_id() {
		return oi_id;
	}
	public void setOi_id(String oi_id) {
		this.oi_id = oi_id;
	}
	public String getPi_id() {
		return pi_id;
	}
	public void setPi_id(String pi_id) {
		this.pi_id = pi_id;
	}
	public String getRl_name() {
		return rl_name;
	}
	public void setRl_name(String rl_name) {
		this.rl_name = rl_name;
	}
	public String getRl_title() {
		return rl_title;
	}
	public void setRl_title(String rl_title) {
		this.rl_title = rl_title;
	}
	public String getRl_content() {
		return rl_content;
	}
	public void setRl_content(String rl_content) {
		this.rl_content = rl_content;
	}
	public String getRe_img() {
		return re_img;
	}
	public void setRe_img(String re_img) {
		this.re_img = re_img;
	}
	public String getRl_ip() {
		return rl_ip;
	}
	public void setRl_ip(String rl_ip) {
		this.rl_ip = rl_ip;
	}
	public String getRl_isview() {
		return rl_isview;
	}
	public void setRl_isview(String rl_isview) {
		this.rl_isview = rl_isview;
	}
	public String getRl_date() {
		return rl_date;
	}
	public void setRl_date(String rl_date) {
		this.rl_date = rl_date;
	}
	public int getRl_idx() {
		return rl_idx;
	}
	public void setRl_idx(int rl_idx) {
		this.rl_idx = rl_idx;
	}
	public int getPs_idx() {
		return ps_idx;
	}
	public void setPs_idx(int ps_idx) {
		this.ps_idx = ps_idx;
	}
	public int getRl_read() {
		return rl_read;
	}
	public void setRl_read(int rl_read) {
		this.rl_read = rl_read;
	}
	public int getRl_good() {
		return rl_good;
	}
	public void setRl_good(int rl_good) {
		this.rl_good = rl_good;
	}
	public double getRl_score() {
		return rl_score;
	}
	public void setRl_score(double rl_score) {
		this.rl_score = rl_score;
	}	
}