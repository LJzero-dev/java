package vo;

public class ProductCtgrSmall {
	private String pcs_id, pcb_id,	pcs_name;

	public String getPcs_id() {
		return pcs_id;
	}

	public void setPcs_id(String pcs_id) {
		this.pcs_id = pcs_id;
	}

	public String getPcb_id() {
		return pcb_id;
	}

	public void setPcb_id(String pcb_id) {
		this.pcb_id = pcb_id;
	}

	public String getPcs_name() {
		return pcs_name;
	}

	public void setPcs_name(String pcs_name) {
		this.pcs_name = pcs_name;
	}	
}
